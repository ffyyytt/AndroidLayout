package com.example.layoutmaster2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    String layout_string_default = "EditText\n"
            +"TextView:abc\n"
            +"Button:btn\n"
            +"TextView:xyz";
    LinearLayout Llayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    0);
        }

        Llayout = (LinearLayout)findViewById(R.id.layout);

        File path = android.os.Environment.getExternalStorageDirectory();


        File file = new File(path, "Your_layout.txt");
        if (!file.exists()) {//create new if file not exists
            FileOutputStream stream = null;
            try {
                stream = new FileOutputStream(file);
                stream.write(layout_string_default.getBytes());
                stream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals("EditText"))
                {
                    EditText edt = new EditText(getApplicationContext());
                    edt.setTextColor(this.getResources().getColor(R.color.black));
                    edt.setHintTextColor(this.getResources().getColor(R.color.colorAccent));
                    edt.setHint("Hint");
                    Llayout.addView(edt);
                }
                else if (line.indexOf("TextView") > -1)
                {
                    TextView tv = new TextView(getApplicationContext());
                    tv.setTextColor(this.getResources().getColor(R.color.black));
                    tv.setTextSize(30);
                    tv.setText(line.substring(9));//len("TextView:") == 9
                    Llayout.addView(tv);
                }
                else if (line.indexOf("Button") > -1)
                {
                    Button btn = new Button(getApplicationContext());
                    btn.setText(line.substring(7));//len("Button:") == 9
                    //btn.setId();
                    Llayout.addView(btn);
                }
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }

    }
}