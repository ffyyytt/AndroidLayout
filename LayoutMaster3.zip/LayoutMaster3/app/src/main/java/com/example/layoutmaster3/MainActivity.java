package com.example.layoutmaster3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String layout;
    LinearLayout Llayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Llayout = (LinearLayout) findViewById(R.id.layout);

        //https://stackoverflow.com/questions/17141829/android-read-text-file-from-internet
        new Thread() {
            @Override
            public void run() {
                String path = "https://raw.githubusercontent.com/ffyyytt/AndroidLayout/main/layout.txt";
                URL u = null;
                try {
                    u = new URL(path);
                    final HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.connect();
                    InputStream in = c.getInputStream();
                    final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    in.read(buffer); // Read from Buffer.
                    bo.write(buffer); // Write Into Buffer.

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            layout = bo.toString();

                            String elements[] = layout.split("\n");
                            for (int i = 0; i < elements.length; i++) {
                                String line = elements[i].substring(0, elements[i].length() - 1);
                                if (line.equals("EditText")) {
                                    EditText edt = new EditText(getApplicationContext());
                                    edt.setTextColor(Color.parseColor("#6200EE"));
                                    edt.setHintTextColor(Color.parseColor("#000000"));
                                    edt.setHint("Hint");
                                    Llayout.addView(edt);
                                } else if (line.indexOf("TextView") > -1) {
                                    TextView tv = new TextView(getApplicationContext());
                                    tv.setTextColor(Color.parseColor("#000000"));
                                    tv.setTextSize(30);
                                    tv.setText(line.substring(9));//len("TextView:") == 9
                                    Llayout.addView(tv);
                                } else if (line.indexOf("Button") > -1) {
                                    Button btn = new Button(getApplicationContext());
                                    btn.setText(line.substring(7));//len("Button:") == 9
                                    //btn.setId();
                                    Llayout.addView(btn);
                                }
                            }

                            try {
                                bo.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            c.disconnect();
                            return;
                        }
                    });

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }.start();

    }

}