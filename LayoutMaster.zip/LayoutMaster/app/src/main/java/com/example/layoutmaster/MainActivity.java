package com.example.layoutmaster;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity{
    GridLayout GL;
    Button btn1, btn2, btn3, btn4, sbtn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final int x[] = {0,1,2,3};
        final int y[] = {0,1,2,3};
        GL = (GridLayout)findViewById(R.id.GridLayout);
        tv = (TextView)findViewById(R.id.TextView);
        btn1 = (Button)findViewById(R.id.button1);
        btn2 = (Button)findViewById(R.id.button2);
        btn3 = (Button)findViewById(R.id.button3);
        btn4 = (Button)findViewById(R.id.button4);
        sbtn = (Button)findViewById(R.id.sbtn);
        setAllbtnxy(GL, x, y);

        sbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("Shuffle");
                int[] x_temp = shuffleArray(x);
                int[] y_temp = shuffleArray(y);
                Shuffle(GL, x_temp, y_temp);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText( "Clicked: "+btn1.getText());
                Toast.makeText(getApplicationContext(), "Clicked: "+btn1.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText( "Clicked: "+btn2.getText());
                Toast.makeText(getApplicationContext(), "Clicked: "+btn2.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText( "Clicked: "+btn3.getText());
                Toast.makeText(getApplicationContext(), "Clicked: "+btn3.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText( "Clicked: "+btn4.getText());
                Toast.makeText(getApplicationContext(), "Clicked: "+btn4.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setAllbtnxy(GridLayout _GL, int[] _x, int[] _y) {
        _GL.removeAllViews();
        setbtnxy(_GL, btn1,_x[0],_y[0]);
        setbtnxy(_GL, btn2,_x[1],_y[1]);
        setbtnxy(_GL, btn3,_x[2],_y[2]);
        setbtnxy(_GL, btn4,_x[3],_y[3]);
    }

    private void setbtnxy(GridLayout _GL, Button _btn, int _x, int _y) {
        GridLayout.Spec row = GridLayout.spec(_x);
        GridLayout.Spec column = GridLayout.spec(_y);
        _GL.addView(_btn, new GridLayout.LayoutParams(row, column));
    }

    private void Shuffle(GridLayout _GL, int[] _x, int[] _y) {
        setAllbtnxy(_GL, _x, _y);
    }

    private static int[] shuffleArray(int[] _array)
    {
        int[] array = _array.clone();
        int index;
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--)
        {
            index = random.nextInt(i + 1);
            if (index != i)
            {
                array[index] ^= array[i];
                array[i] ^= array[index];
                array[index] ^= array[i];
            }
        }
        return array;
    }
}
