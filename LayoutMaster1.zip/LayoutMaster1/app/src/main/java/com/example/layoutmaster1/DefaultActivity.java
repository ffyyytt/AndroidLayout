package com.example.layoutmaster1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class DefaultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //File này để intent qua bên kia tránh bị bug

        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        String layout = 1+"";
        i.putExtra("layout", layout);
        startActivity(i);

    }
}