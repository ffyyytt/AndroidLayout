package com.example.layoutmaster1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class MainActivity extends AppCompatActivity {
    EditText A, B;
    TextView tv;
    Button addbtn, layoutbtn;
    int i_layout = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        if (bundle == null)
        {
            setContentView(R.layout.layout1);
            Toast.makeText(getApplicationContext(),"NULL",Toast.LENGTH_SHORT).show();
        }
        else
        {
            i_layout = Integer.parseInt(bundle.getString("layout"));
            Toast.makeText(getApplicationContext(),""+i_layout,Toast.LENGTH_SHORT).show();
            if (i_layout == 1)
            {
                setContentView(R.layout.layout1);
            }
            else
            {
                setContentView(R.layout.layout2);
            }
        }
        A = (EditText)findViewById(R.id.EditTextA);
        B = (EditText)findViewById(R.id.EditTextB);
        tv = (TextView)findViewById(R.id.TextView);
        addbtn = (Button)findViewById(R.id.addbtn);
        layoutbtn = (Button)findViewById(R.id.layoutbtn);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int intA = Integer.parseInt(A.getText().toString());
                    int intB = Integer.parseInt(B.getText().toString());
                    tv.setText(""+(intA+intB));
                } catch(NumberFormatException nfe) {
                    System.out.println("Could not parse " + nfe);
                }
            }
        });

        layoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                String layout = (3-i_layout)+"";
                i.putExtra("layout", layout);
                startActivity(i);
            }
        });

    }
}